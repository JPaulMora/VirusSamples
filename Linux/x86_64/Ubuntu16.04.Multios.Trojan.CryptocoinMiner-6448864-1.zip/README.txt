Weblogic - Cryptominer
Add Tag (Tags are public)
malware remote cryptomining weblogic
/var/tmp
-sustes Pobably executable
-sustes3 ???????
-wc.conf crypotoserver configuration file
Detection:
RiskWare[RiskTool]/Android.Miner.b

Arcabit
Application.Linux.BitCoinMiner.N

Avast
ELF:BitCoinMiner-BB [Tool]

AVG
ELF:BitCoinMiner-BB [Tool]

Avira
LINUX/BitCoinMiner.ozghk

BitDefender
Application.Linux.BitCoinMiner.N

ClamAV
Multios.Trojan.CryptocoinMiner-6448864-1

Cyren
Trojan.KREB-11

DrWeb
Tool.Linux.BtcMine.729

Emsisoft
Application.Linux.BitCoinMiner.N (B)

eScan
Application.Linux.BitCoinMiner.N

ESET-NOD32
Linux/CoinMiner.CN

F-Secure
Application.Linux.BitCoinMiner

Fortinet
Riskware/Miner

GData
Linux.Application.CoinMiner.AH (2x)

Ikarus
Trojan.Linux.Coinminer

Jiangmin
RiskTool.Linux.adw

Kaspersky
not-a-virus:RiskTool.HTML.Miner.b

MAX
malware (ai score=81)

McAfee
Linux/Miner.a

McAfee-GW-Edition
Linux/Miner.a

Microsoft
Trojan:Win32/Occamy.C

NANO-Antivirus
Riskware.Elf64.BitCoinMiner.fbgtmh

Qihoo-360
virus.js.qexvmc.1

Sophos AV
Coinminer Config (PUA)

TrendMicro
Coinmin.CF4D7CFA

TrendMicro-HouseCall
Coinmin.CF4D7CFA

ZoneAlarm
not-a-virus:RiskTool.HTML.Miner.b

Bundle Info
Warnings
Contains one or more Linux executables.
Contents Metadata
Contained Files	6
Uncompressed Size	4723798
Earliest Member Modification	2018-05-24 06:34:41
Latest Member Modification	2018-09-28 04:25:02
Contained Files By Type
Unknown	3
ELF	2
Contained Files By Extension
Tmp	1
Swp	1

Sybase iAnywhere database files (41.3%)
TAR - Tape ARchive (GNU) (36.9%)
TAR - Tape ARchive (directory) (21.7%)

Password: CryptoniteCryptoMalware